#!/bin/bash

# TechResona - Update Backend URL Script
# This script updates the backend URL in the built frontend files

echo "======================================"
echo "  Update Backend URL in Frontend"
echo "======================================"
echo ""

# Check if running from the right directory
if [ ! -d "frontend" ]; then
    echo "Error: frontend/ directory not found!"
    echo "Please run this script from the techresona-production/ directory"
    exit 1
fi

# Get the new backend URL from user
read -p "Enter your backend URL (e.g., https://api.yourdomain.com): " BACKEND_URL

if [ -z "$BACKEND_URL" ]; then
    echo "Error: Backend URL cannot be empty!"
    exit 1
fi

echo ""
echo "Updating backend URL to: $BACKEND_URL"
echo ""

# Old URL to replace
OLD_URL="https://70348ab8-3af8-40b4-bf87-a1e24cae3c64.preview.emergentagent.com"

# Update in all JavaScript files
if command -v find &> /dev/null; then
    echo "Searching for files to update..."
    
    # Find and update all JS files
    find frontend/ -type f \( -name "*.js" -o -name "*.html" \) -exec sed -i.bak "s|$OLD_URL|$BACKEND_URL|g" {} \;
    
    # Remove backup files
    find frontend/ -type f -name "*.bak" -delete
    
    echo "✓ Updated backend URL in all files"
    echo ""
    echo "Old URL: $OLD_URL"
    echo "New URL: $BACKEND_URL"
    echo ""
    echo "✓ Done! Your frontend is ready to deploy."
else
    echo "Warning: 'find' command not available."
    echo "Please manually replace the following URL in your files:"
    echo "  Old: $OLD_URL"
    echo "  New: $BACKEND_URL"
fi

echo ""
echo "======================================"
