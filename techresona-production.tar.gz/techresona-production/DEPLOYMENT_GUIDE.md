# 🚀 TechResona Production Deployment Guide

## 📦 Package Contents

This production build contains:

```
techresona-production/
├── frontend/           # Built static files (Astro production build)
├── backend/            # FastAPI backend application
└── DEPLOYMENT_GUIDE.md # This file
```

## 🎯 Deployment Options

### Option 1: Traditional Hosting (Recommended for Full-Stack)

Best for: VPS, Dedicated Server, Cloud VM (DigitalOcean, AWS EC2, Linode, etc.)

#### Requirements:
- Ubuntu/Debian server with root access
- Python 3.11+
- MongoDB
- Nginx/Apache
- Domain name (optional but recommended)

#### Step 1: Upload Files

```bash
# Upload to your server via SCP/SFTP
scp -r techresona-production/ user@your-server:/var/www/
```

Or use FileZilla, WinSCP, or your hosting control panel.

#### Step 2: Setup Backend

```bash
# SSH into your server
ssh user@your-server

# Navigate to backend directory
cd /var/www/techresona-production/backend

# Install Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env file (IMPORTANT!)
nano .env
```

Add to `.env`:
```env
MONGO_URL=mongodb://localhost:27017
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/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
```

#### Step 3: Install & Start MongoDB

```bash
# Install MongoDB (Ubuntu/Debian)
sudo apt update
sudo apt install -y mongodb

# Start MongoDB
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

#### Step 4: Setup Systemd Service for Backend

Create `/etc/systemd/system/techresona-backend.service`:

```ini
[Unit]
Description=TechResona Backend API
After=network.target mongodb.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/techresona-production/backend
Environment="PATH=/var/www/techresona-production/backend/venv/bin"
EnvironmentFile=/var/www/techresona-production/backend/.env
ExecStart=/var/www/techresona-production/backend/venv/bin/uvicorn server:app --host 0.0.0.0 --port 8001
Restart=always

[Install]
WantedBy=multi-user.target
```

Start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl start techresona-backend
sudo systemctl enable techresona-backend
sudo systemctl status techresona-backend
```

#### Step 5: Setup Nginx for Frontend & Backend

Create `/etc/nginx/sites-available/techresona`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    # Frontend (Static Files)
    root /var/www/techresona-production/frontend;
    index index.html;

    # Serve static files
    location / {
        try_files $uri $uri/ $uri.html =404;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:8001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/techresona /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### Step 6: Setup SSL with Let's Encrypt (HTTPS)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renewal is set up automatically
```

### Option 2: Separate Hosting (Frontend + Backend Split)

#### Frontend: Netlify, Vercel, or Cloudflare Pages

**Upload only the `frontend/` folder**

1. **Netlify:**
   - Drag and drop `frontend/` folder to Netlify
   - Or connect to Git and it deploys automatically

2. **Vercel:**
   - Import project from Git
   - Build command: (already built)
   - Output directory: `frontend`

3. **Cloudflare Pages:**
   - Connect to Git or upload `frontend/` folder

**Update Backend URL:**
Create `.env` in your deployment:
```env
PUBLIC_BACKEND_URL=https://your-backend-api.com
```

#### Backend: Railway, Render, or Heroku

**Upload only the `backend/` folder**

1. **Railway.app:**
   ```bash
   # Install Railway CLI
   npm i -g @railway/cli
   
   # Login
   railway login
   
   # Deploy
   cd backend
   railway init
   railway up
   
   # Add MongoDB
   railway add mongodb
   
   # Set environment variables
   railway variables set SLACK_WEBHOOK_URL=your_webhook_url
   ```

2. **Render.com:**
   - Create new Web Service
   - Connect to Git or upload `backend/` folder
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - Add MongoDB database
   - Set environment variables

3. **Heroku:**
   ```bash
   cd backend
   git init
   heroku create techresona-api
   heroku addons:create mongolab
   heroku config:set SLACK_WEBHOOK_URL=your_webhook_url
   git add .
   git commit -m "Deploy backend"
   git push heroku main
   ```

### Option 3: Docker Deployment

Create `docker-compose.yml` in the root:

```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8001:8001"
    environment:
      - MONGO_URL=mongodb://mongodb:27017
      - SLACK_WEBHOOK_URL=your_webhook_url
    depends_on:
      - mongodb

  frontend:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./frontend:/usr/share/nginx/html
      - ./nginx.conf:/etc/nginx/conf.d/default.conf

  mongodb:
    image: mongo:7
    ports:
      - "27017:27017"
    volumes:
      - mongodb_data:/data/db

volumes:
  mongodb_data:
```

Deploy:
```bash
docker-compose up -d
```

## 🔧 Environment Variables

**Backend (.env):**
```env
MONGO_URL=mongodb://localhost:27017          # MongoDB connection
SLACK_WEBHOOK_URL=https://hooks.slack.com... # Your Slack webhook
```

**Frontend (.env):**
```env
PUBLIC_BACKEND_URL=https://your-backend-url.com  # Backend API URL
```

## ✅ Post-Deployment Checklist

- [ ] Backend is running (check: `https://yourdomain.com/api/health`)
- [ ] MongoDB is connected
- [ ] Slack webhook is configured
- [ ] Frontend loads correctly
- [ ] Contact form submits successfully
- [ ] Slack notifications are received
- [ ] SSL certificate is installed (HTTPS)
- [ ] DNS is configured correctly
- [ ] Test form at: `https://yourdomain.com/contact`

## 🧪 Testing Your Deployment

### Test Backend Health
```bash
curl https://yourdomain.com/api/health
```

Should return:
```json
{
  "status": "healthy",
  "database": "connected",
  "slack_configured": true
}
```

### Test Form Submission
```bash
curl -X POST https://yourdomain.com/api/enquiries \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "phone": "+91 9876543210",
    "company": "Test Co",
    "message": "Test message"
  }'
```

### Check Slack
- Submit a test form
- Verify notification appears in Slack channel

### Check Database
```bash
curl https://yourdomain.com/api/enquiries
```

## 🔒 Security Recommendations

1. **Update CORS Settings** (backend/server.py):
   ```python
   app.add_middleware(
       CORSMiddleware,
       allow_origins=["https://yourdomain.com"],  # Change from "*"
       allow_credentials=True,
       allow_methods=["POST", "GET"],
       allow_headers=["*"],
   )
   ```

2. **Add Rate Limiting:**
   ```bash
   pip install slowapi
   ```

3. **Secure Environment Variables:**
   - Never commit `.env` files to Git
   - Use server environment variables

4. **Setup Firewall:**
   ```bash
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```

5. **Regular Updates:**
   ```bash
   sudo apt update && sudo apt upgrade
   ```

## 📊 Monitoring & Logs

### View Backend Logs (Systemd)
```bash
sudo journalctl -u techresona-backend -f
```

### View Nginx Logs
```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Check Service Status
```bash
sudo systemctl status techresona-backend
sudo systemctl status mongodb
sudo systemctl status nginx
```

## 🆘 Troubleshooting

### Backend Not Responding
```bash
# Check if backend is running
sudo systemctl status techresona-backend

# View logs
sudo journalctl -u techresona-backend -n 50

# Restart backend
sudo systemctl restart techresona-backend
```

### Database Connection Issues
```bash
# Check MongoDB status
sudo systemctl status mongodb

# Test connection
mongo --eval "db.adminCommand('ping')"

# Restart MongoDB
sudo systemctl restart mongodb
```

### Slack Notifications Not Working
- Verify webhook URL in `.env` file
- Test with curl:
  ```bash
  curl -X POST https://hooks.slack.com/services/YOUR/WEBHOOK/URL \
    -H "Content-Type: application/json" \
    -d '{"text":"Test message"}'
  ```
- Check backend logs for errors

### Frontend Not Loading
```bash
# Check Nginx status
sudo systemctl status nginx

# Test Nginx config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Check file permissions
sudo chown -R www-data:www-data /var/www/techresona-production/frontend
```

## 📱 Contact Form URL

After deployment, your contact form will be accessible at:
```
https://yourdomain.com/contact
```

## 🎉 You're Done!

Your TechResona website with contact form backend is now live! 

**Key URLs:**
- Website: `https://yourdomain.com`
- Contact Form: `https://yourdomain.com/contact`
- API Health: `https://yourdomain.com/api/health`
- DecapCMS: `https://yourdomain.com/admin/index.html`

**What happens when someone submits the form:**
1. ✅ Form data is validated
2. ✅ Data is saved to MongoDB
3. ✅ Notification is sent to your Slack channel
4. ✅ User receives success message

## 📚 Additional Resources

- Backend API Docs: See `backend/README.md`
- DecapCMS Setup: See `DECAPCMS_SETUP.md`
- Implementation Details: See `IMPLEMENTATION_SUMMARY.md`

## 🔄 Updates & Maintenance

To update your site:
1. Make changes to source code
2. Rebuild: `npm run build`
3. Upload new `frontend/` folder
4. Restart backend if needed: `sudo systemctl restart techresona-backend`

---

**Need Help?** Refer to the troubleshooting section or check the logs!
